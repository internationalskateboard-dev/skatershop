// lib/constants.ts
// Constantes globales reutilizables en la tienda.

export const PRODUCT_PLACEHOLDER_IMAGE = "/images/placeholder.png";
