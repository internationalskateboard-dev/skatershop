// placeholder util para futuras llamadas al backend o PayPal server-side
export async function createOrderOnServer() {
  return { ok: true }
}
